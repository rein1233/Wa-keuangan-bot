# 📱 Bot WhatsApp Pencatat Keuangan

Bot WhatsApp untuk mencatat pengeluaran ke file Excel dan Google Spreadsheet.

## Perintah
- `catat 50000 makan siang`
- `rekap juni`

## Cara Deploy
1. Buat Google Service Account
2. Simpan key di `.env`
3. Jalankan `npm start`